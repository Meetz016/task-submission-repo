import { useState } from "react";

function Calculator() {
    const buttonStyle = "flex justify-center items-center border border-gray-300 bg-gray-700 text-white rounded-2xl w-16 h-16 text-xl font-semibold shadow-md hover:bg-gray-500 hover:text-slate-100";
    const operatorStyles = "flex justify-center items-center border border-gray-300 bg-amber-500 text-white rounded-2xl w-16 h-16 text-xl font-semibold shadow-md hover:bg-amber-500";

    const [value, setValue] = useState("");
    const [isCalculated, setIsCalculated] = useState(false);

    function clearAll() {
        setValue("");
        setIsCalculated(false);
    }

    function deleteLast() {
        setValue(value.toString().slice(0, -1));
    }

    function result() {
        try {
            setValue(eval(value).toString());
            setIsCalculated(true);
        } catch {
            setValue("Error");
            setIsCalculated(true);
        }
    }

    function handleClick(e) {
        if (isCalculated) {
            setValue(e.target.innerHTML); 
            setIsCalculated(false);
        } else {
            setValue(value + e.target.innerHTML);
        }
    }

    return (
        <div className="flex items-center justify-center min-h-screen bg-gray-100">
            <div className="bg-gray-800 w-96 p-4 rounded-xl shadow-2xl">
                <div className="bg-gray-900 text-white text-right p-4 mb-4 rounded-lg text-2xl font-mono">
                    {value || "0"}
                </div>
                <div className="grid grid-rows-5 grid-cols-4 gap-3">
                    <div onClick={clearAll} className={operatorStyles}>AC</div>
                    <div onClick={deleteLast} className={operatorStyles}>Del</div>
                    <div onClick={handleClick} className={operatorStyles}>.</div>
                    <div onClick={handleClick} className={operatorStyles}>/</div>
                    <div onClick={handleClick} className={buttonStyle}>7</div>
                    <div onClick={handleClick} className={buttonStyle}>8</div>
                    <div onClick={handleClick} className={buttonStyle}>9</div>
                    <div onClick={handleClick} className={operatorStyles}>*</div>
                    <div onClick={handleClick} className={buttonStyle}>4</div>
                    <div onClick={handleClick} className={buttonStyle}>5</div>
                    <div onClick={handleClick} className={buttonStyle}>6</div>
                    <div onClick={handleClick} className={operatorStyles}>-</div>
                    <div onClick={handleClick} className={buttonStyle}>1</div>
                    <div onClick={handleClick} className={buttonStyle}>2</div>
                    <div onClick={handleClick} className={buttonStyle}>3</div>
                    <div onClick={handleClick} className={operatorStyles}>+</div>
                    <div className={`${buttonStyle} col-span-1`}>
                        <img src="src/assets/companylogo.jpg" alt="logo" className="object contain" />
                    </div>
                    <div onClick={handleClick} className={buttonStyle}>0</div>
                    <div onClick={handleClick} className={buttonStyle}>00</div>
                    <div onClick={result} className={operatorStyles}>=</div>
                </div>
            </div>
        </div>
    );
}

export default Calculator;
