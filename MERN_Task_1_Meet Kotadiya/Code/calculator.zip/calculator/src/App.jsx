
import './App.css'
import Calculator from './components/Calculator'
function App() {
  return (
    <div>
      {/* display section */}
      {/* 5x4 section */}
      {/* first row -> AC, remove character,percentage,divide */}
      {/* second row -> 7, 8 ,9,multiplication */}
      {/* third row -> 4,5,6,minus */}
      {/* 4th row -> 1,2,3,+ */}
      {/* 5th row-> company logo,0,.,= */}
      {/* creating a usable row component for all buttons */}
      <Calculator/>
    </div>
  )
}

export default App
